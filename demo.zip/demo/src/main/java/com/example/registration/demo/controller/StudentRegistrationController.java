package com.example.registration.demo.controller;

import com.example.registration.demo.entity.Student;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class StudentRegistrationController {

    @GetMapping("/register-student")
    public String showStudentRegistrationForm() {
        return "register-student";
    }

    @PostMapping("/register-student")
    public String registerStudent(@ModelAttribute Student student) {
        // Save student to database (use StudentService)
        return "redirect:/dashboard";
    }
}

