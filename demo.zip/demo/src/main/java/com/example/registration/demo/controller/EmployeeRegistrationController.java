package com.example.registration.demo.controller;

import com.example.registration.demo.entity.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EmployeeRegistrationController {

    @GetMapping("/register-employee")
    public String showEmployeeRegistrationForm() {
        return "register-employee";
    }

    @PostMapping("/register-employee")
    public String registerEmployee(@ModelAttribute Employee employee) {
        // Save employee to database (use EmployeeService)
        return "redirect:/dashboard";
    }
}

